package com.yongbeom.aircalendar;

import android.content.Context;


public class AirCalendar {
    public void init(Context context){

    }
}
