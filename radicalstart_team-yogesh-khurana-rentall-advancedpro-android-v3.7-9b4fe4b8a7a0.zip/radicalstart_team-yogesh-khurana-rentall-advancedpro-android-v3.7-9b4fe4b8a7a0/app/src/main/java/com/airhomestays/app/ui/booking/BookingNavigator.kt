package com.airhomestays.app.ui.booking

import com.airhomestays.app.ui.base.BaseNavigator

interface BookingNavigator: BaseNavigator {

    fun navigateToScreen(screen : Int)

}