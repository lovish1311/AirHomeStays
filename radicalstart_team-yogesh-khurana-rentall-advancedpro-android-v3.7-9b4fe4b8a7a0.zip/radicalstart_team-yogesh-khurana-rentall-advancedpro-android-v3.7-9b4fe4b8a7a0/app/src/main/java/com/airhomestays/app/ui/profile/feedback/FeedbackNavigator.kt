package com.airhomestays.app.ui.profile.feedback

import com.airhomestays.app.ui.base.BaseNavigator

interface FeedbackNavigator: BaseNavigator