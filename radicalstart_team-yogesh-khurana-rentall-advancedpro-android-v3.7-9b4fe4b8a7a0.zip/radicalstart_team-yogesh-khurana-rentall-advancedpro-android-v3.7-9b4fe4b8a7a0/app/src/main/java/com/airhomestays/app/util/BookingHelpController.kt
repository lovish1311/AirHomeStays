package com.airhomestays.app

import com.airbnb.epoxy.EpoxyController

class BookingHelpController(
    private val handlers: ViewholderHelpBooking.Handlers
) : EpoxyController() {

    override fun buildModels() {
        viewholderHelpBooking {
            id("booking_help")
            handlers(this@BookingHelpController.handlers)
        }
    }
}
