package com.airhomestays.app.ui.trips.contactus

import com.airhomestays.app.ui.base.BaseNavigator

interface ContactUsNavigator : BaseNavigator {

    fun closeDialog()
}