package com.airhomestays.app.ui.host.hostReservation.hostContactUs

import com.airhomestays.app.ui.base.BaseNavigator

interface HostContactUsNavigator : BaseNavigator {

    fun closeDialog()
}