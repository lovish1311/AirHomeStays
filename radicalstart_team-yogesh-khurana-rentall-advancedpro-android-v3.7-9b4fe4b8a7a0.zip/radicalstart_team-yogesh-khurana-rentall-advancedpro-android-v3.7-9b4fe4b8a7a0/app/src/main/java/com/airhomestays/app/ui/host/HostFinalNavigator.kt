package com.airhomestays.app.ui.host

import com.airhomestays.app.ui.base.BaseNavigator

interface HostFinalNavigator : BaseNavigator {

    fun show404Screen()

    fun showListDetails()

}