package com.airhomestays.app.vo

class CurrencyException(message: String) : Exception(message)
