package com.airhomestays.app.ui.cancellation

import com.airhomestays.app.ui.base.BaseNavigator

interface CancellationNavigator: BaseNavigator {

    fun moveBackScreen()
}