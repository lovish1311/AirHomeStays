package com.airhomestays.app.services

interface MyBroadcastListener {
    fun doSomething(online:Boolean)
}
