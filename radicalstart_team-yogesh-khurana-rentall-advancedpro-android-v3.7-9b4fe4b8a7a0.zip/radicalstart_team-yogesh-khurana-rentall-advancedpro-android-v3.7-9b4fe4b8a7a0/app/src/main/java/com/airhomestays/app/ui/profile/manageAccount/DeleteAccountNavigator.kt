package com.airhomestays.app.ui.profile.manageAccount

import com.airhomestays.app.ui.base.BaseNavigator

interface DeleteAccountNavigator : BaseNavigator {

    fun closeDialog()
}