package com.airhomestays.app.ui.user_profile

import com.airhomestays.app.ui.base.BaseNavigator

interface UserProfileNavigator: BaseNavigator {

   /* fun openReviews()

    fun reportUsers()

    fun openVerified()*/

    fun closeScreen()
}