package com.airhomestays.app.services

import android.app.IntentService
import android.content.Intent

class ImageUploadService : IntentService("ImageUploadService") {

    override fun onHandleIntent(intent: Intent?) {

    }
}