package com.airhomestays.app.ui.payment.razorpay

class VerifyOrderResponse {
    var status:String?=""
}