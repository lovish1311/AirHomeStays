package com.airhomestays.app.host.payout.editpayout

data class CommonModel(var header:String,var subHeader:String)
