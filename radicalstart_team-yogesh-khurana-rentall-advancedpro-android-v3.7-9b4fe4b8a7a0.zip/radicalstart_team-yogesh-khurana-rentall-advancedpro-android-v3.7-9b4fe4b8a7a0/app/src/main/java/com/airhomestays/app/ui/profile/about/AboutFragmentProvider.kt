package com.airhomestays.app.ui.profile.about

import com.airhomestays.app.ui.reservation.ItineraryFragment
import com.airhomestays.app.ui.reservation.ReceiptFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Suppress("unused")
@Module
abstract class AboutFragmentProvider {

}