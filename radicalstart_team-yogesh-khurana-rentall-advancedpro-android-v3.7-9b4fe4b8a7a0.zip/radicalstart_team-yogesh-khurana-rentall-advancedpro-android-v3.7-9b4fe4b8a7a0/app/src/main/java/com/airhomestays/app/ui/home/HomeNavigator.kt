package com.airhomestays.app.ui.home

import com.airhomestays.app.ui.base.BaseNavigator

interface HomeNavigator: BaseNavigator {

    fun initialAdapter()

}