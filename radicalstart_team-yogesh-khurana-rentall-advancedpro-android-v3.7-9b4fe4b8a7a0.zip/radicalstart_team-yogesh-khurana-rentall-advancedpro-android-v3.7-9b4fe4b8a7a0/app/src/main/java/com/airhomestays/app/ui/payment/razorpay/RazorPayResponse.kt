package com.airhomestays.app.ui.payment.razorpay

data class RazorPayResponse(
    val data: Data?
)

data class Data(
    val id: String?
)